<div  id="loguin-index" class="container-sm indexContainers" style="display:none;">
    
    <div class="container" >
    
        <form class="cajon form-horizontal" action="/action_page.php">
        <input type="hidden" name="view" value="loguin">
        <p class="h4 text-center"> LOGUIN: </p>
            <div class="form-group">
            <label class="control-label col-sm-2" for="usuario">Usuario:</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="usuario" name="usuario">
            </div>
            </div>
            <div class="form-group">
            <label class="control-label col-sm-2" for="pass">Contraseña:</label>
            <div class="col-sm-10">          
                <input type="password" class="form-control" id="pass" name="pass">
            </div>
            </div>
            <div class="form-group">        
            <div class="col-sm-offset-2 col-sm-10">
                <div class="checkbox">
                <label><input type="checkbox" name="remember"> Recuérdame </label>
                </div>
            </div>
            </div>
            <div class="form-group">        
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit"  id="buttom-submit class="btn btn-default">Entrar</button>
            </div>
            </div>
        </form>

    </div>
</div>