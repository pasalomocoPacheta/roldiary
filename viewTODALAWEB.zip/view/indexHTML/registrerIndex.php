<?php include controladorBase.php ?>

<div id="registrer-index" class="container-sm indexContainers" style="display:none;">
   
    <div class="container indexContainers" >

        <form class="cajon form-horizontal" action="/action_page.php">
        <input type="hidden" name="view" value="registrer">
        <p class="h4 text-center"> REGISTRO: </p>
            <div class="form-group">
            <label class="control-label col-sm-2" for="usuario">Usuario:</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="usuario" name="usuario">
            </div>
            </div>
            <div class="form-group">
            <label class="control-label col-sm-2" for="pass">Contraseña:</label>
            <div class="col-sm-10">          
                <input type="password" class="form-control" id="pass" name="pass">
            </div>
            </div>
            <div class="form-group">        
            <div class="col-sm-offset-2 col-sm-10">
                <div class="checkbox">
                <label><input type="checkbox" name="narrador"> Registrarse como Narrador </label>
                </div>
            </div>
            </div>
            <div class="form-group">        
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit"  id="buttom-submit class="btn btn-default">Registrarse</button>
            </div>
            </div>
            <input type="hidden" name="date" value="<?php date('Y-m-d H:i:s'); ?>">
        </form>
    </div>
</div>