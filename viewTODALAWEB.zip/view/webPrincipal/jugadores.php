<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "../generalHTML/headLinksMeta.html"; ?> 

</head>
<body>
    <?php include "header.html"; ?> 

    <main id="containerPrincipal" class="container">
    <?php include "../nav/nav.html"; ?> 
<!-- 
 AQUÍ PONDRÁ NARRADOR O JUGADOR EN FUNCIÓN DE QUIÉN HAYA INICIADO SESIÓN      -->
<p class="h1 text-center separador"> NARRADOR </p>
<div class="container">
 
    <div class="row">
      <div class="col-sm">
        <p class="h2 text-left">  JUGADORES: </p> 
      </div>
      <div class="col-sm">
      </div>
      <div class="col-sm">
        <button id="botonMostrarJugadores" class="text-left"> Mostrar jugadores  </button>
      </div>
    </div>
 
</div>
  
<!--  LOS DATOS DE LA BBDD SOBRE LOS JUGADORES   -->
<?php include "../jugadores/tablaJugadores.php"; ?>     


</div>


<?php include "../generalHTML/footer.html"; ?>   

</main>
<!--  BOTONES MOSTRAR / OCULTAR LA TABLA DE LOS DATOS  -->

<?php include "../jquery/jqueryJugadores.html" ?>

    
</body>
</html>