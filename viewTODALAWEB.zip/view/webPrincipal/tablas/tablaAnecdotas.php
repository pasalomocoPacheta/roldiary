<div id="mostrandoAnecdotas" class="row" style="display:block;">
          
    <table class="table table-striped">
        <p class="h4 text-center separador"> MOSTRANDO ANÉCDOTAS </p>
        <thead>
          <tr>
            <!-- ESTO VIENE DE UN CAMPO HIDDEN DE CUÁNDO SE AÑADIÓ -->
            <th scope="col">Fecha </th>
            <!-- JUGADOR QUE AÑADIÓ LA ANÉCDOTA -->
            <th scope="col"> Jugador  </th>
            <th scope="col"> Contenido </th>
            <th scope="col"> Links </th>
             <!-- CADA ANÉCDOTA SE INCLUYE DENTRO DE UNA SESIÓN DE JUEGO -->
            <th scope="col"> Sesión de juego asociada </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            
            <td>Mark</td>
            <td>Otto</td>
            <td>@mdo</td>
            <td>sfsdf</td>
            <td>Otsdfto</td>
            <td>@sdfdsf</td>

          </tr>
          <tr>
            
            <td>Jacob</td>
            <td>Thornton</td>
            <td>@fat</td>
          </tr>
          <tr>
        
            <td>Larry</td>
            <td>the Bird</td>
            <td>@twitter</td>
          </tr>
        </tbody>
      </table>



</div>