<div id="mostrandoPersonajes" class="row" style="display:block;">
          
    <table class="table table-striped">
        <p class="h4 text-center separador"> MOSTRANDO PERSONAJES </p>
        <thead>
          <tr>
            <th scope="col">Fecha </th>
            <th scope="col"> Nombre </th>
            <th scope="col"> Descripción corta </th>
            <th scope="col"> Descripción completa </th>
            <th scope="col"> Campañas asociadas </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            
            <td>Mark</td>
            <td>Otto</td>
            <td>@mdo</td>
            <td>sfsdf</td>
            <td>Otsdfto</td>
            <td>@sdfdsf</td>

          </tr>
          <tr>
            
            <td>Jacob</td>
            <td>Thornton</td>
            <td>@fat</td>
          </tr>
          <tr>
        
            <td>Larry</td>
            <td>the Bird</td>
            <td>@twitter</td>
          </tr>
        </tbody>
      </table>



</div>