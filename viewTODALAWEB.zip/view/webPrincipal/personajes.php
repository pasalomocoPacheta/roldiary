<!DOCTYPE html>
<html lang="en">
<head>
  <?php include "../generalHTML/headLinksMeta.html"; ?> 
</head>
<body>

<?php include "header.html"; ?> 

    <main id="containerPrincipal" class="container">
    <?php include "../nav/nav.html"; ?> 

      <!-- 
 AQUÍ PONDRÁ NARRADOR O JUGADOR EN FUNCIÓN DE QUIÉN HAYA INICIADO SESIÓN      -->
      <p class="h1 text-center separador"> NARRADOR </p>
      <div class="container">
       
          <div class="row">
            <div class="col-sm">
              <p class="h2 text-left">  PERSONAJES: </p> 
            </div>
            <div class="col-sm">
              <button id="botonIncluirPersonaje" class="text-left"> Añadir personajes </button>
            </div>
            <div class="col-sm">
              <button id="botonMostrarPersonajes" class="text-left"> Mostrar personajes  </button>
            </div>
          </div>
       
      </div>
        
   <?php include "../personajes/tablaPersonajes.php"; ?>     
   <?php include "../personajes/formularioIncluirPersonaje.php"; ?>  
     
  </div>


  <?php include "../generalHTML/footer.html"; ?>   
    
      </main>
  <?php include "../jquery/jqueryPersonajes.html" ?>
    
</body>
</html>