<?php
   require_once "view/personajes.php";
?>