-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2021 at 09:32 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `roldiary`
--

-- --------------------------------------------------------

--
-- Table structure for table `anecdotas`
--

CREATE TABLE `anecdotas` (
  `id_anecdotas` int(11) NOT NULL,
  `contenido` varchar(900) NOT NULL,
  `campania` varchar(90) NOT NULL,
  `fk_personaje_escritor` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `jugadores`
--

CREATE TABLE `jugadores` (
  `id_jugadores` int(11) NOT NULL,
  `nombre` varchar(35) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `admin` tinyint(4) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jugadores`
--

INSERT INTO `jugadores` (`id_jugadores`, `nombre`, `pass`, `admin`, `fecha_registro`) VALUES
(3, 'admin', '123', 1, '2021-03-31 18:14:41'),
(4, 'ojete', '$2y$10$d.S7SC4v9S6AfwbjyjZi9OJ/xKXyawgbGm/ZaeVBgIQqP0sn/sSdG', 0, '2021-03-31 18:31:04');

-- --------------------------------------------------------

--
-- Table structure for table `personajes`
--

CREATE TABLE `personajes` (
  `id_personajes` int(11) NOT NULL,
  `nombre` varchar(90) NOT NULL,
  `descripcion` varchar(900) NOT NULL,
  `fk_jugador_asociado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `personajes`
--

INSERT INTO `personajes` (`id_personajes`, `nombre`, `descripcion`, `fk_jugador_asociado`) VALUES
(4, 'hth', ' rhtrh', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anecdotas`
--
ALTER TABLE `anecdotas`
  ADD PRIMARY KEY (`id_anecdotas`),
  ADD KEY `fk_personaje_escritor_` (`fk_personaje_escritor`);

--
-- Indexes for table `jugadores`
--
ALTER TABLE `jugadores`
  ADD PRIMARY KEY (`id_jugadores`);

--
-- Indexes for table `personajes`
--
ALTER TABLE `personajes`
  ADD PRIMARY KEY (`id_personajes`),
  ADD KEY `fk_jugador_asociado` (`fk_jugador_asociado`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anecdotas`
--
ALTER TABLE `anecdotas`
  MODIFY `id_anecdotas` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jugadores`
--
ALTER TABLE `jugadores`
  MODIFY `id_jugadores` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `personajes`
--
ALTER TABLE `personajes`
  MODIFY `id_personajes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `anecdotas`
--
ALTER TABLE `anecdotas`
  ADD CONSTRAINT `fk_personaje_escritor_` FOREIGN KEY (`fk_personaje_escritor`) REFERENCES `personajes` (`id_personajes`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `personajes`
--
ALTER TABLE `personajes`
  ADD CONSTRAINT `fk_personaje_escritor` FOREIGN KEY (`fk_jugador_asociado`) REFERENCES `jugadores` (`id_jugadores`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
