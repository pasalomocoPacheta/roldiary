<?php
  
   require "view/admin.php";
?>