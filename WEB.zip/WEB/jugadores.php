<?php
   require "view/jugadores.php";
?>