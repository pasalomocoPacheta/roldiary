<?php
   require "view/anecdotas.php";
?>