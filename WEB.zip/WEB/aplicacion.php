<?php
  require_once "view/indexAPLICACION.php"; 
?>