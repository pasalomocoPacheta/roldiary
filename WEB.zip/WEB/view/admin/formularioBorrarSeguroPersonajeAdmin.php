<span class="formularioEliminarDefinitivamente"> 
    <span class='btn-danger'> 
        <a style='color:black' href='admin.php?BorrarDefinitivamentePersonaje=<?php if(isset($_GET["IDBorrarPersonaje"])){echo$_GET["IDBorrarPersonaje"];} ?>'> 
        BORRAR DEFINITIVAMENTE A <?php if(isset($_GET["NombrePersonaje"])){echo$_GET["NombrePersonaje"];} ?>
    </a>
    </span>
</span>

