<span class="formularioEliminarDefinitivamente"> 
    <span class='btn-danger'> 
        <a style='color:black' href='admin.php?BorrarDefinitivamenteAnecdota=<?php if(isset($_GET["IDBorrarAnecdota"])){echo$_GET["IDBorrarAnecdota"];} ?>'> 
        CLICK PARA BORRAR DEFINITIVAMENTE
    </a>
    </span>
</span>

