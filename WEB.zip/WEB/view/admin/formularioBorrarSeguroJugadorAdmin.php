<span class="formularioEliminarDefinitivamente" > 
    <span class='btn-danger'> 
        <a style='color:black' href='admin.php?BorrarDefinitivamenteJugador=<?php if(isset($_GET["Borrar"])){echo$_GET["Borrar"];} ?>'> 
        BORRAR DEFINITIVAMENTE A <?php if(isset($_GET["Borrar"])){echo$_GET["Borrar"];} ?>
    </a>
    </span>
</span>





