<?php
     require_once 'controller/ControladorVistas.php';
     session_start();
     $mvc = new ControladorVistas();
     $mvc->redirigirIndexSinoEsAdmin();
     require_once "controller/controladorAdministrador.php" ;
    require_once "model/modeloBase.php" ;
    require_once "model/jugadores.php" ;
    require_once "model/personajes.php" ;
    require_once "model/anecdotas.php" ;
   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "css/headLinksMeta.html"; ?> 

</head>
<body>
    <?php include "headerAPLICACION.php"; ?> 

    <!-- ESTO LO PONGO AQUÍ PARA QUE APAREZCA EL FORMULARIO DE BORRAR DEFINITIVAMENTE ARRIBA DEL CONTAINER PRINCIPAL  -->
<div id="wrap">
  <div id="main" class="container clear-top">  
      <?php ControladorAdministrador::borrarJugador();     ?>
      <?php ControladorAdministrador::borrarPersonaje();     ?>
      <?php ControladorAdministrador::borrarAnecdota();     ?>

      <main id="containerPrincipal" class="container">
        

            <p class="h1 text-center separador">
                <?php  
                   
                  echo "<br>";  
                  echo  $_SESSION['sess_user'];
                ?> 
            </p>
            <!--  LOS DATOS DE LA BBDD SOBRE LOS JUGADORES   -->
            <?php ControladorAdministrador::controladorVistasAdmin();     ?>
               
            </div>
      </main>
  </div>
</div>
<!-- BOTÓN SUBIR ARRIBA -->
<a id="back-to-top" href="#" class="btn btn-light btn-lg back-to-top" role="button"><i class="fas fa-chevron-up"></i></a>

<?php include "footer.html"; ?>  

<!--  BOTONES MOSTRAR / OCULTAR LA TABLA DE LOS DATOS  -->

<?php include "jquery/jqueryAccionEditarEliminar.html" ?>
<?php include "jquery/jqueryAdmin.html" ?>

    
</body>
</html>
