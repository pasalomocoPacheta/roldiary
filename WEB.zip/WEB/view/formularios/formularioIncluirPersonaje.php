<div id="formularioIncluirPersonaje" class="formulario-incluir container-sm indexContainers">
        <p class="h4 text-center separador"> AÑADIR NUEVO PERSONAJE </p>
        <form class="cajon form-horizontal" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
            <input type="hidden" name="hiddenFecha" value="<?php echo date('Y-m-d H:i:s');?>">
            <div class="form-group">
              <label class="control-label col-sm-12"> Nombre </label>
              <div class="col-sm-10">
                  <input type="text" class="form-control" name="nombrePersonaje">
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-sm-12">Descripción </label>
              <div class="col-sm-10">
                  <textarea class="form-control" name="descripcion"> </textarea>
              </div>
            </div>
            <input type="submit" name="CrearPersonaje" value="Crear personaje">
        </form>

  </div>















<!-- 
    <div class="form-group">
              <label class="control-label col-sm-12" for="campaniaAsociada">Campaña asociada:</label>
              <div class="col-sm-10">
                <select name="campaniaAsociada" id="campaniaAsociada">
                  <option value="volvo">aasd</option>
                  <option value="saab">sad</option>
                  <option value="opel">asd</option>
                  <option value="audi">Audasdi</option>
                </select>
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-sm-12" for="jugadores">Jugador asociado</label>
              <div class="col-sm-10">          
                <select name="jugadores" id="jugadores">
                  <option value="volvo">Volvo</option>
                  <option value="saab">Saab</option>
                  <option value="opel">Opel</option>
                  <option value="audi">Audi</option>
                </select>
              </div>
    </div> -->