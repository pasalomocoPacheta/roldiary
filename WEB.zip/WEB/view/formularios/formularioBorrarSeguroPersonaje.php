<div class="formularioEditarBorrar indexContainers">
        <div class="indexContainers">
            <span class='btn-danger'> 
                <a style='color:black' href='personajes.php?BorrarDefinitivamentePersonaje=<?php if(isset($_GET["IDBorrarPersonaje"])){echo$_GET["IDBorrarPersonaje"];} ?>'> 
                BORRAR DEFINITIVAMENTE A <?php if(isset($_GET["NombrePersonaje"])){echo$_GET["NombrePersonaje"];} ?>
            </a>
            </span>
        </div>

</div>


