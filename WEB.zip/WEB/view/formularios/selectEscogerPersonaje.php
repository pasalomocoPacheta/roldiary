<div class="container indexContainers">
    <div class="row">
      <div class="col-sm">
        <p class="h2 text-left">  PERSONAJES: </p> 
      </div>
      <div class="col-sm">
            
                <form action="" method="POST">
                        <select name="personajesDisponibles"  class="form-control">
                        <?php 
                                for($i=0 ; $i < count($tablaPersonajes); $i++ ) {
                                  // Solo puedes escoger personajes creador por el jugador
                                  if($_SESSION['id_jugadores'] == $tablaPersonajes[$i]->fk_jugador_asociado){
                                    $nombrePersonaje= $tablaPersonajes[$i]->nombre;
                                    echo"<option value='$nombrePersonaje'>$nombrePersonaje</option>";  
                                  }               
                            }
                            ?> 
                        </select>
            <input type="submit" name="seleccionarPersonaje" value="Seleccionar personaje y comenzar a escribir">      
        </form>
      </div>
      <div class="col-sm">
        <button id="botonIncluirPersonaje" class="boton-incluir text-left"> Añadir personajes  </button>
      </div>
      <div class="col-sm">
        <button id="botonMostrarPersonajes" class="boton-mostrar text-left"> Mostrar personajes  </button>
      </div>
    </div>
 
</div>



