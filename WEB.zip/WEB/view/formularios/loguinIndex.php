<?php         
            
             include "controller/controladorInicioSesion.php";
             $controladorInicio = new controladorInicioSesion();
             $controladorInicio->formularioLoguin(); 
?>
<div  id="loguin-index" class="container-sm indexContainers" style="display:none;">
    
    <div class="container" >
    
        <form class="cajon form-horizontal" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <input type="hidden" name="viewPersonajes" value="loguin">
        <p class="h4 text-center"> LOGIN: </p>
            <div class="form-group">
            <label class="control-label col-sm-2" for="usuario">Usuario:</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="usuario">
            </div>
            </div>
            <div class="form-group">
            <label class="control-label col-sm-2" for="pass">Contraseña:</label>
            <div class="col-sm-10">          
                <input type="password" class="form-control" name="pass">
            </div>
            </div>
            <!-- <div class="form-group">        
            <div class="col-sm-offset-2 col-sm-10">
                <div class="checkbox">
                <label><input type="checkbox" name="remember"> Recuérdame </label>
                </div>
            </div>
            </div> -->
            <div class="form-group">        
            <div class="col-sm-offset-2 col-sm-10">
                <input id="buttom-submit class="btn btn-default" type="submit" name="submitLoguin" value="Entrar" > 
            </div>
            </div>
        </form>

    </div>
</div>