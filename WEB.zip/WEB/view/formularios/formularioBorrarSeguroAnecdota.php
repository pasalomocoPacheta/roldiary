<div class="formularioEditarBorrar indexContainers">
        <div class="indexContainers">
                <span class='btn-danger'> 
                    <a style='color:black' href='anecdotas.php?BorrarDefinitivamenteAnecdota=<?php if(isset($_GET["IDBorrarAnecdota"])){echo$_GET["IDBorrarAnecdota"];} ?>'> 
                    CLICK PARA BORRAR DEFINITIVAMENTE
                    </a>
                </span>
        </div>
</div>
