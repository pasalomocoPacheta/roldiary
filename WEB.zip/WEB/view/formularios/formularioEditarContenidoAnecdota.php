<div  class="formularioEditarBorrar formulario-incluir indexContainers">
    <div class="container-sm" >

    <p class="h4 text-center separador"> EDITAR CONTENIDO ANÉCDOTA  </p>
            <form class="cajon form-horizontal indexContainers" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
            <input type="hidden" name="IDEditarContenidoAnecdota" value="<?php echo $_GET['IDEditarContenidoAnecdota']; ?>">

                <div class="form-group">
                <label class="control-label col-sm-12">Contenido </label>
                <div class="col-sm-10">
                    <textarea class="form-control" name="contenidoAnecdota"> </textarea>
                </div>
                </div>
                <input type="submit" name="editarContenidoAnecdota" value="Editar anecdota">
            </form>
      </div>    
</div>    
