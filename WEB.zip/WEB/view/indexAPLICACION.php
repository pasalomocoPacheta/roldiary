<!-- <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
---- Include the above in your HEAD tag 
https://aprende-web.net/javascript/js7_2.php
-------- -->

<!doctype html>
<html lang="en">
<head>
    <?php include "css/headLinksMeta.html"; ?> 
</head>
<body>

<?php include "headerAPLICACION.php"; ?>


<div id="wrap">
  <div id="main" class="container clear-top">

  <main id="containerPrincipal" class="container">

        <?php include "formularios/registrerIndex.php"; ?> 
        <?php include "formularios/loguinIndex.php"; ?> 
        <?php include "indexHTML/presentacionWEB.html"; ?>           
            
    </main>

  </div>
</div>
<!-- BOTÓN SUBIR ARRIBA -->
<a id="back-to-top" href="#" class="btn btn-light btn-lg back-to-top" role="button"><i class="fas fa-chevron-up"></i></a>

<?php include "footer.html"; ?>   



<?php include "jquery/jqueryIndex.html"; ?>  


</body>
</html>
