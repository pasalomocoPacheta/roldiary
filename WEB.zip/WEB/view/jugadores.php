<?php 
   require_once 'controller/ControladorVistas.php';
   session_start();
   $mvc = new ControladorVistas();
   $mvc->redirigirIndexSinoInicioSesion();
  require_once "model/modeloBase.php" ;
  require_once "model/jugadores.php" ;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "css/headLinksMeta.html"; ?> 

</head>
<body>
    <?php include "headerAPLICACION.php"; ?> 

<div id="wrap">
  <div id="main" class="container clear-top">

        <main id="containerPrincipal" class="container">
                
                    <!-- AQUÍ PONDRÁ NARRADOR O JUGADOR EN FUNCIÓN DE QUIÉN HAYA INICIADO SESIÓN      -->
                    <p class="h1 text-center separador"> 
                            <?php  
                            
                            if(isset( $_SESSION['sess_user'])){
                                    echo "JUGADOR: ". $_SESSION['sess_user'];
                                }
                                    ?> 
                    </p>
                            
                            <!--  LOS DATOS DE LA BBDD SOBRE LOS JUGADORES   -->
                <?php include "tablas/tablaJugadores.php"; ?>     

        </main>
  </div>
</div>
<!-- BOTÓN SUBIR ARRIBA -->
<a id="back-to-top" href="#" class="btn btn-light btn-lg back-to-top" role="button"><i class="fas fa-chevron-up"></i></a>

<?php include "footer.html"; ?> 

<!--  BOTONES MOSTRAR / OCULTAR LA TABLA DE LOS DATOS  -->

<?php include "jquery/jqueryJugadores.html" ?>

    
</body>
</html>
