<nav class="navbar navbar-expand-lg navbar-light">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                  <ul class="navbar-nav">
                    <li class="nav-item navbar-brand">
                        <button>
                            <?php  
                            
                            if(isset($_SESSION['sess_user']) && $_SESSION['sess_user'] == "admin") { 
                                echo "<a class='nav-link' href='admin.php'>PERSONAJES</a>";
                                } else{
                                echo "<a class='nav-link' href='personajes.php'>PERSONAJES</a>";
                                } 
                            ?>
                        </button>
                    </li>
                        
                    <li class="nav-item">
                        <button>
                        <?php  
                            if(isset($_SESSION['sess_user']) && $_SESSION['sess_user'] == "admin") { 
                                echo "<a class='nav-link' href='admin.php'>JUGADORES</a>";
                            } else{
                                echo "<a class='nav-link' href='jugadores.php'>JUGADORES</a>";
                            } 
                        ?>
                        </button>
                    </li>
                      <li class="nav-item">
                        <button>
                            <?php  
                            
                            if(isset($_SESSION['sess_user']) && $_SESSION['sess_user'] == "admin") { 
                                echo "<a class='nav-link' href='admin.php'>ANECDOTAS</a>";
                                } else{
                                echo "<a class='nav-link' href='anecdotas.php'>ANECDOTAS</a>";
                                } 
                            ?>
                        </button>
                      </li>
            
                  </ul>
                </div>
</nav>