<?php
return array(
    "host"      =>"127.0.0.1",
    "user"      =>"root",
    "pass"      =>"",
    "database"  =>"roldiary",
    "charset"   =>"utf8"
);
?>
