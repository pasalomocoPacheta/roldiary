<?php
class RecuperadorVista{
 
    public function viex ($view){

        require_once 'view/'.$view.'.php';

    }
  
 }
?>
