<?php
class ControladorVistas{
 
    // Se utiliza para invocar el archivo que contiene las vistas
    public static function vistasIndex(){

        require_once "view/indexAPLICACION.php";        

    }

     public static function RedirigirvistasAplicacion(){

        ControladorVistas::redirigirIndexSinoInicioSesion();

            if($_SESSION['sess_user'] == "admin"){

                echo "<script type='text/javascript'> document.location = 'admin.php'; </script>";

            }else{
                if(isset($_SESSION["idPersonajeSelecionado"])){
                    echo "<script type='text/javascript'> document.location = 'anecdotas.php'; </script>";
                } else if(isset($_SESSION["id_jugadores"])){
                    echo "<script type='text/javascript'> document.location = 'personajes.php'; </script>";
                }
               
            }

            

    }

    public static function redirigirAnecdotas (){

        if(isset($_SESSION['idPersonajeSelecionado'])){
            echo "<script type='text/javascript'> document.location = 'anecdotas.php'; </script>";
        }

    }

     public static function redirigirIndexSinoInicioSesion (){

        if(!(isset($_SESSION['sess_user']))){
            echo "<script type='text/javascript'> document.location = 'index.php'; </script>";
        }

    }

     public static function redirigirIndexSinoEsAdmin (){
        if(isset( $_SESSION['sess_user']) && $_SESSION['sess_user'] == "admin"){
            // echo "<script type='text/javascript'> document.location = 'admin.php'; </script>";
        } else{
            echo "<script type='text/javascript'> document.location = 'index.php'; </script>";
        }
    }

     public static function cerrarSesion(){
        $_SESSION = array();
        session_destroy();
        setcookie(session_name(), time()-1000);
        echo "<script type='text/javascript'> document.location = 'index.php'; </script>";
    }

    // public function jugadores ($usuario){

    //     require_once "view/webPrincipal/personajes.php";
    //     Los header location no me han funcionado bien https://stackoverflow.com/questions/21226166/php-header-location-redirect-not-working/30283281
    //     https://stackoverflow.com/questions/2710079/php-header-location-redirect-doesnt-work-why
    //     echo "<script type='text/javascript'> document.location = 'view/webPrincipal/personajes.php'; </script>";
    // }


  
 }
?>

