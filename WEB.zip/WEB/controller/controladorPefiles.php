<?php 
class ControladorPersonajes extends ControladorVistas{

    public static function comprobarSiHayPerfil (){
        $personajes = new Personaje ("personajes");
        if(isset($_SESSION['id_jugadores'])){
            $tablaPersonajesFkJugador = $personajes->getAllByFkJugador($_SESSION['id_jugadores']);
            if($tablaPersonajesFkJugador == "0 resultados devueltos" ){
                echo "<p class='h5 text-center separador'>NO TIENES PERSONAJES, AÑADE EL PRIMERO:</p>";
                require_once "view/formularios/formularioIncluirPersonaje.php";
            }else{
                $tablaPersonajes = $personajes->getAll();
                echo "<p class='h5 text-center separador'>Selecciona un personaje para escribir una anécdota o añade uno nuevo</p>";
                require_once "view/formularios/selectEscogerPersonaje.php";
                require_once "view/formularios/formularioIncluirPersonaje.php";
                require_once "view/tablas/tablaPersonajes.php"; 
            }
        } else{
            ControladorPersonajes::RedirigirvistasAplicacion();
        }
        
    
    }

    public static function borrarPerfil(){

        require_once 'model/modeloBase.php';
        require_once 'model/personajes.php';
        $personaje = new Personaje("personajes");
        if(isset($_GET["IDBorrarPersonaje"]) ){
            include "view/formularios/formularioBorrarSeguroPersonaje.php" ;
        }
        if(isset($_GET["BorrarDefinitivamentePersonaje"])){
            echo $_GET["BorrarDefinitivamentePersonaje"];
            $personaje->deleteById($_GET["BorrarDefinitivamentePersonaje"]);
            echo "<script>
                  alert('Personaje eliminado');
                </script>";    
            ControladorPersonajes::RedirigirvistasAplicacion();
        }

    }

    public static function formularioComenzarAescribirAnecdotasConPersonaje(){

        if(isset($_POST["seleccionarPersonaje"])){

            $_SESSION['nombrePersonajeSelecionado'] = $_POST["personajesDisponibles"];
            $personaje = new Personaje("personajes");
            $_SESSION['idPersonajeSelecionado'] = (int) $personaje->getIdByNombre( $_POST["personajesDisponibles"]);
            ControladorPersonajes::redirigirAnecdotas();
        }



    }

    public static function crearPersonaje($nombrePersonaje, $descripcion){
        $personajes = new Personaje ("personajes");
        $personajes->setNombre($nombrePersonaje);
        $personajes->setDescripcion($descripcion);
        $personajes->setFkJugadorAsociado($_SESSION['id_jugadores']);
        if( $personajes->save()){
            echo "<script type=\"text/javascript\">
            alert('Personaje creado con exito');
                 </script>";
            ControladorPersonajes::RedirigirvistasAplicacion();
        } else{
            echo "<script type=\"text/javascript\">
            alert('Fallo en la creacion');
             </script>";
            ControladorPersonajes::RedirigirvistasAplicacion();
        }
        
    }

    public static function formularioCreacionPersonaje (){
        $errores = null;
        
        if(isset($_POST["CrearPersonaje"])){
              
               unset($_POST["CrearPersonaje"]); 
             
            if(!empty($_POST["nombrePersonaje"])){
                $nombrePersonaje = $_POST["nombrePersonaje"];
            } else{
                $errores .= "Introduce un nombre.";
            }
            if(!empty($_POST["descripcion"])){
                $descripcion = $_POST["descripcion"];
            } else{
                $errores .= "Falta descripcion.";
            }

            if($errores == null){
                // echo "Usuario introducido correctamente";
                ControladorPersonajes::crearPersonaje($nombrePersonaje, $descripcion);
            } else{
                $errores .= "Rellena los datos que faltan.";
                echo "<script type=\"text/javascript\">
                         alert('$errores');
                      </script>";
            }

        }
        
        


    }


}
?>